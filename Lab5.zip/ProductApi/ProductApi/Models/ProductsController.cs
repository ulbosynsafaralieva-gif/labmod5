﻿using Microsoft.AspNetCore.Mvc;
using ProductApi.Models;

namespace ProductApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private static List<Product> products = new()
        {
            new Product { Id = 1, Name = "Notebook", Description = "Ноутбук для работы и учёбы", Price = 350000, Quantity = 5 },
            new Product { Id = 2, Name = "Mouse", Description = "Беспроводная мышь", Price = 8000, Quantity = 15 },
            new Product { Id = 3, Name = "Keyboard", Description = "Механическая клавиатура", Price = 15000, Quantity = 10 }
        };

        [HttpGet]
        public ActionResult<List<Product>> GetAll()
        {
            return Ok(products);
        }

        [HttpGet("{id}")]
        public ActionResult<Product> GetById(int id)
        {
            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();
            return Ok(product);
        }

        [HttpPost]
        public ActionResult<Product> Create(Product newProduct)
        {
            if (newProduct == null || string.IsNullOrWhiteSpace(newProduct.Name))
                return BadRequest();

            newProduct.Id = products.Any() ? products.Max(p => p.Id) + 1 : 1;
            products.Add(newProduct);
            return CreatedAtAction(nameof(GetById), new { id = newProduct.Id }, newProduct);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Product updated)
        {
            if (updated == null || string.IsNullOrWhiteSpace(updated.Name))
                return BadRequest();

            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();

            product.Name = updated.Name;
            product.Description = updated.Description;
            product.Price = updated.Price;
            product.Quantity = updated.Quantity;

            return Ok(product);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();

            products.Remove(product);
            return Ok();
        }
    }
}