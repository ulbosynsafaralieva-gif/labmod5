﻿using System.Net.Http.Json;
using ProductClient.Models;

namespace ProductClient.Services
{
    public class ProductApiService : IProductApiService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ProductApiService(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<List<Product>> GetAllAsync()
        {
            var client = _httpClientFactory.CreateClient("ProductApi");
            var response = await client.GetAsync("api/products");

            if (!response.IsSuccessStatusCode)
                return new List<Product>();

            var products = await response.Content.ReadFromJsonAsync<List<Product>>();
            return products ?? new List<Product>();
        }

        public async Task<Product?> GetByIdAsync(int id)
        {
            var client = _httpClientFactory.CreateClient("ProductApi");
            var response = await client.GetAsync($"api/products/{id}");

            if (!response.IsSuccessStatusCode)
                return null;

            return await response.Content.ReadFromJsonAsync<Product>();
        }

        public async Task<(bool Success, string? Error)> CreateAsync(Product product)
        {
            var client = _httpClientFactory.CreateClient("ProductApi");
            var response = await client.PostAsJsonAsync("api/products", product);

            if (response.IsSuccessStatusCode)
                return (true, null);

            return (false, BuildErrorMessage(response.StatusCode));
        }

        public async Task<(bool Success, string? Error)> UpdateAsync(Product product)
        {
            var client = _httpClientFactory.CreateClient("ProductApi");
            var response = await client.PutAsJsonAsync($"api/products/{product.Id}", product);

            if (response.IsSuccessStatusCode)
                return (true, null);

            return (false, BuildErrorMessage(response.StatusCode));
        }

        public async Task<(bool Success, string? Error)> DeleteAsync(int id)
        {
            var client = _httpClientFactory.CreateClient("ProductApi");
            var response = await client.DeleteAsync($"api/products/{id}");

            if (response.IsSuccessStatusCode)
                return (true, null);

            return (false, BuildErrorMessage(response.StatusCode));
        }

        private static string BuildErrorMessage(System.Net.HttpStatusCode statusCode)
        {
            return statusCode switch
            {
                System.Net.HttpStatusCode.BadRequest => "Некорректные данные товара.",
                System.Net.HttpStatusCode.NotFound => "Товар не найден.",
                System.Net.HttpStatusCode.InternalServerError => "Внутренняя ошибка сервера. Попробуйте позже.",
                _ => $"Непредвиденная ошибка. Код: {(int)statusCode}"
            };
        }
    }
}