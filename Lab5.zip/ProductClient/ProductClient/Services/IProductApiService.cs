﻿using ProductClient.Models;

namespace ProductClient.Services
{
    public interface IProductApiService
    {
        Task<List<Product>> GetAllAsync();
        Task<Product?> GetByIdAsync(int id);
        Task<(bool Success, string? Error)> CreateAsync(Product product);
        Task<(bool Success, string? Error)> UpdateAsync(Product product);
        Task<(bool Success, string? Error)> DeleteAsync(int id);
    }
}