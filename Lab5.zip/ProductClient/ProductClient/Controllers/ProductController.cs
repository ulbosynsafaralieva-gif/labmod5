﻿using Microsoft.AspNetCore.Mvc;
using ProductClient.Models;
using ProductClient.Services;

namespace ProductClient.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductApiService _apiService;

        public ProductController(IProductApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _apiService.GetAllAsync();
            return View(products);
        }

        public async Task<IActionResult> Details(int id)
        {
            var product = await _apiService.GetByIdAsync(id);

            if (product == null)
            {
                ViewBag.ErrorMessage = "Товар не найден.";
                return View("NotFoundProduct");
            }

            return View(product);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            var (success, error) = await _apiService.CreateAsync(product);

            if (!success)
            {
                ModelState.AddModelError(string.Empty, error ?? "Не удалось создать товар.");
                return View(product);
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var product = await _apiService.GetByIdAsync(id);

            if (product == null)
            {
                ViewBag.ErrorMessage = "Товар не найден.";
                return View("NotFoundProduct");
            }

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            product.Id = id;
            var (success, error) = await _apiService.UpdateAsync(product);

            if (!success)
            {
                ModelState.AddModelError(string.Empty, error ?? "Не удалось изменить товар.");
                return View(product);
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            await _apiService.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}